# scraper.py

import requests
from bs4 import BeautifulSoup
import pandas as pd
from config import HEADERS, SEARCH_URL

def fetch_page(url):
    try:
        response = requests.get(url, headers=HEADERS)
        response.raise_for_status()  # Raise an HTTPError for bad responses
        print(f"Successfully fetched {url}")
        return response.text
    except requests.exceptions.RequestException as e:
        print(f"Failed to fetch {url}: {e}")
        return None

def parse_disease_page(html):
    soup = BeautifulSoup(html, 'html.parser')
    data = {
        'Disease Name': '',
        'Overview': '',
        'Key Facts': '',
        'Symptoms': '',
        'Causes': '',
        'Types': '',
        'Risk factors': '',
        'Diagnosis': '',
        'Prevention': '',
        'Specialist to visit': '',
        'Treatment': '',
        'Home-care': '',
        'Alternative therapies': '',
        'Living with': '',
        'FAQs': [],
        'References': []
    }

    # Extract relevant information
    data['Disease Name'] = soup.find('h1', class_='disease-title').text if soup.find('h1', class_='disease-title') else ''
    data['Overview'] = soup.find('section', class_='overview').text if soup.find('section', class_='overview') else ''
    data['Key Facts'] = soup.find('section', class_='key-facts').text if soup.find('section', class_='key-facts') else ''
    data['Symptoms'] = soup.find('section', class_='symptoms').text if soup.find('section', class_='symptoms') else ''
    data['Causes'] = soup.find('section', class_='causes').text if soup.find('section', class_='causes') else ''
    data['Types'] = soup.find('section', class_='types').text if soup.find('section', class_='types') else ''
    data['Risk factors'] = soup.find('section', class_='risk-factors').text if soup.find('section', class_='risk-factors') else ''
    data['Diagnosis'] = soup.find('section', class_='diagnosis').text if soup.find('section', class_='diagnosis') else ''
    data['Prevention'] = soup.find('section', class_='prevention').text if soup.find('section', class_='prevention') else ''
    data['Specialist to visit'] = soup.find('section', class_='specialist-to-visit').text if soup.find('section', class_='specialist-to-visit') else ''
    data['Treatment'] = soup.find('section', class_='treatment').text if soup.find('section', class_='treatment') else ''
    data['Home-care'] = soup.find('section', class_='home-care').text if soup.find('section', class_='home-care') else ''
    data['Alternative therapies'] = soup.find('section', class_='alternative-therapies').text if soup.find('section', class_='alternative-therapies') else ''
    data['Living with'] = soup.find('section', class_='living-with').text if soup.find('section', class_='living-with') else ''

    faq_section = soup.find('section', class_='faqs')
    if faq_section:
        for faq in faq_section.find_all('div', class_='faq'):
            question = faq.find('div', class_='question').text if faq.find('div', class_='question') else ''
            answer = faq.find('div', class_='answer').text if faq.find('div', class_='answer') else ''
            data['FAQs'].append({'Question': question, 'Answer': answer})

    references_section = soup.find('section', class_='references')
    if references_section:
        for ref in references_section.find_all('a', href=True):
            data['References'].append(ref['href'])

    return data

def fetch_disease_links():
    html = fetch_page(SEARCH_URL)
    if not html:
        return []

    soup = BeautifulSoup(html, 'html.parser')
    disease_links = [a['href'] for a in soup.find_all('a', class_='disease-link', href=True)]
    return disease_links

def save_to_csv(data, filename='output/diseases.csv'):
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"Saved {len(data)} diseases to {filename}")

def main():
    disease_links = fetch_disease_links()
    if not disease_links:
        print("No disease links found.")
        return

    diseases_data = []
    for link in disease_links:
        full_link = BASE_URL + link  # Ensure the link is absolute
        disease_html = fetch_page(full_link)
        if disease_html:
            data = parse_disease_page(disease_html)
            diseases_data.append(data)
    
    save_to_csv(diseases_data)

if __name__ == "__main__":
    main()
