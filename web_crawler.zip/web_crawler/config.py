# config.py

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

SEARCH_URLS = {
    'Medical Journal': 'https://actualwebsite.com/medical-journals',
    'Blog': 'https://actualwebsite.com/blogs',
    'News': 'https://actualwebsite.com/news'
}

CATEGORIES = {
    'Orthopedic': 'orthopedic',
    'Gynecology': 'gynecology'
}

GEOGRAPHIES = {
    'India': 'india',
    'US': 'us',
    'Europe': 'europe',
    'Latin America': 'latin-america'
}
