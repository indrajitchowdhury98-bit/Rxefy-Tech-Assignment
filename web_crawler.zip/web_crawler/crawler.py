import requests
from bs4 import BeautifulSoup
import pandas as pd
import json
import time

# Import configurations
from config import HEADERS, SEARCH_URLS, CATEGORIES, GEOGRAPHIES

def fetch_page(url):
    try:
        response = requests.get(url, headers=HEADERS)
        response.raise_for_status()  # Raise an HTTPError for bad responses
        print(f"Successfully fetched {url}")
        return response.text
    except requests.exceptions.RequestException as e:
        print(f"Failed to fetch {url}: {e}")
        return None

def parse_page(html):
    soup = BeautifulSoup(html, 'html.parser')
    data = []

    # Extract relevant information; this is a placeholder and should be adapted
    # to the actual structure of the target page.
    for item in soup.find_all('div', class_='item'):
        data.append({
            'title': item.find('h2').text if item.find('h2') else '',
            'description': item.find('p').text if item.find('p') else '',
            'link': item.find('a')['href'] if item.find('a') else ''
        })

    return data

def save_to_csv(data, filename='output/data.csv'):
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"Saved {len(data)} records to {filename}")

def main():
    search_category = 'Blog'
    category = 'Orthopedic'
    geography = 'US'
    date_range = '2022'

    search_url = SEARCH_URLS.get(search_category)
    if not search_url:
        print(f"No URL found for category {search_category}")
        return

    html = fetch_page(search_url)
    if not html:
        return

    data = parse_page(html)
    save_to_csv(data)

if __name__ == "__main__":
    main()
